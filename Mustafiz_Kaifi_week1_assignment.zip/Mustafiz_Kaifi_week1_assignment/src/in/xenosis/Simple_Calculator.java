package in.xenosis;


//3.  Implement a simple calculator using switch-
//        case statements.

import java.util.Scanner;

public class Simple_Calculator {
    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the value of a: ");
        int a=sc.nextInt();
        System.out.println("Enter the value of b: ");
        int b=sc.nextInt();
        System.out.println("choose any symbol from(+,-,*,/): ");
        char op=sc.next().charAt(0);
        if(op=='+' ||op=='-' || op=='*' || op=='/'){
            switch (op){
                case '+':
                    int c=a+b;
                    System.out.print("The sum of both number is : "+c );
                    break;
                case '-':
                    int d=a-b;
                    System.out.println("The subtraction of both number is : "+ d);
                    break;
                case '*':
                    int e=a*b;
                    System.out.print("The multiplication of both number is : "+e );
                    break;
                case '/':
                    int f=a/b;
                    System.out.println("The division of both number is : "+ f);
                    break;
            }
        }
        else {
            System.out.println("please select only above selection");
        }


    }
}
