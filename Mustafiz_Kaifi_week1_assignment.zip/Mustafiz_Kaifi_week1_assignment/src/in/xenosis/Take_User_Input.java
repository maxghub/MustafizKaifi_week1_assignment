package in.xenosis;


//2. Create a program that takes user input and
//        checks if the number is even or odd.

import java.util.Scanner;

public class Take_User_Input {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the any number : ");
        int n=sc.nextInt();
        if(n%2==0){
            System.out.print(n+" is even number ");
        }
        else {
            System.out.println(n+" is a odd number ");
        }
    }
}
